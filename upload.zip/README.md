code-rex
========

This is a reporsitoy for developing mashup application using the KooKoo API for the event Desert Hack 2012.